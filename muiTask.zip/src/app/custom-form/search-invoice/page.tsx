import SearchInvoice from '@/templates/custom-forms/searchInvoice'
import NewInvoice from '@/templates/custom-forms/searchInvoice'
import React from 'react'

const page = () => {
  return (
    <>
<SearchInvoice/>
    </>
  )
}

export default page