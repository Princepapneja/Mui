import CustomForm from '@/templates/custom-forms/customForm'
import React from 'react'

const page = () => {
  return (
    <>
    <CustomForm/>
    </>
  )
}

export default page