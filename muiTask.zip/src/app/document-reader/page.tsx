import DocumentReader from '@/templates/documentReader'
import React from 'react'

const page = () => {
  return (
    <>
    <DocumentReader/>
    </>
  )
}

export default page